package Programme;

public class StringCompress {
	public static void compress(String str)
	{
	String res = "";
	
	if (str != null && !str.isEmpty()) 
	{
	int count = 0;
	char currChar = 0, prevChar = 0;
	
	for (int i = 0; i < str.length(); i++)
	{
		
	if (i == 0) 
	{
	currChar = prevChar = str.charAt(i);
	}
	
	currChar = str.charAt(i);

	if (currChar != prevChar) {
	res = res + prevChar + count;
	count = 1;
	}
	else {
	count++;
	}
	prevChar = currChar;
	}
	res = res + prevChar + count;
	System.out.println("Compression Result:" + res);
	}

}
	
	
	public static void main(String[] args) {
		
		compress("aaabbcccd");
		
		}

}
